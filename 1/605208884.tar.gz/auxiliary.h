#ifndef AUXILIARY_H
#define AUXILIARY_H

void fatalError(const char* prefix);
void generalError(const char* message);

#endif
