#ifndef HANDLEREQUEST_H
#define HANDLEREQUEST_H



int handlerequest(int socketfd);
int printrequest(int socketfd, int outputfd);



#endif
